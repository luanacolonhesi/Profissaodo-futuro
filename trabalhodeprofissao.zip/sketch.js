function setup() {
  createCanvas(900, 700);
  background(245, 230, 245);

  // Título
  fill(120, 0, 120);
  textSize(30);
  textStyle(BOLD);
  textAlign(CENTER);
  text("Minha Profissão do Futuro", width / 2, 50);

  // Subtítulo
  textSize(22);
  text("Biomédica Esteta", width / 2, 90);

  // Caixa de informações
  fill(255);
  stroke(180);
  rect(40, 120, 820, 520, 15);

  noStroke();
  fill(0);
  textAlign(LEFT);
  textSize(18);

  let texto =
  "Nome: Luana Colonhesi\n\n" +

  "Escola: Dom Pedro II\n\n" +

  "Série/Turma: 3A\n\n" +

  "O que faz uma Biomédica Esteta?\n" +
  "É a profissional da área da saúde responsável por realizar\n" +
  "procedimentos estéticos faciais e corporais, promovendo\n" +
  "beleza, autoestima e bem-estar dos pacientes.\n\n" +

  "Pontos positivos:\n" +
  "• Boa remuneração.\n" +
  "• Mercado em crescimento.\n" +
  "• Pode abrir sua própria clínica.\n" +
  "• Ajuda na autoestima das pessoas.\n\n" +

  "Pontos negativos:\n" +
  "• Precisa estudar constantemente.\n" +
  "• Grande responsabilidade profissional.\n" +
  "• Equipamentos possuem custo elevado.\n\n" +

  "Por que escolhi essa profissão?\n" +
  "Porque gosto da área da saúde, da estética e de ajudar\n" +
  "as pessoas a se sentirem mais felizes e confiantes.";

  text(texto, 70, 160);
}

function draw() {

  // Cruz da saúde
  fill(220, 0, 80);
  noStroke();
  rect(720, 500, 25, 80);
  rect(692, 528, 80, 25);

  // Rosto simples
  fill(255, 220, 190);
  ellipse(770, 250, 120, 140);

  fill(0);
  ellipse(750, 235, 8);
  ellipse(790, 235, 8);

  noFill();
  stroke(0);
  arc(770, 270, 40, 20, 0, PI);
}